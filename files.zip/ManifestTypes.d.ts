/*
 * Auto-generated types for CampusAI PCF Component
 * Do not edit manually
 */

export interface IInputs {
    userRole: ComponentFramework.PropertyTypes.StringProperty;
    userName: ComponentFramework.PropertyTypes.StringProperty;
    agentEndpoint: ComponentFramework.PropertyTypes.StringProperty;
    adminFlowUrl: ComponentFramework.PropertyTypes.StringProperty;
}

export interface IOutputs {
    userRole?: string;
    userName?: string;
    lastMessage?: string;
    activeScreen?: string;
}

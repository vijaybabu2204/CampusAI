import { IInputs, IOutputs } from "./generated/ManifestTypes";

// ─── Types ───────────────────────────────────────────────────────────────────

type Screen = "splash" | "welcome" | "login" | "chat" | "admin";

interface Message {
    id: string;
    role: "user" | "assistant" | "system";
    text: string;
    time: string;
    status?: "sending" | "sent" | "error";
}

interface AppState {
    screen: Screen;
    userRole: "student" | "admin" | "guest";
    userName: string;
    messages: Message[];
    adminLog: AdminEntry[];
    isTyping: boolean;
    inputValue: string;
    agentEndpoint: string;
    adminFlowUrl: string;
    notifyOutputChanged: () => void;
    lastMessage: string;
    activeScreen: string;
}

interface AdminEntry {
    id: string;
    command: string;
    status: "pending" | "success" | "error";
    time: string;
    response: string;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

const now = () =>
    new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });

const uid = () => Math.random().toString(36).slice(2, 9);

// ─── Styles ──────────────────────────────────────────────────────────────────

const STYLES = `
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

.campus-root {
    width: 100%;
    height: 100%;
    min-height: 600px;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    background: #0d0d0d;
    color: #ececec;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    position: relative;
}

/* ── SPLASH ── */
.screen-splash {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    background: #0d0d0d;
    animation: fadeIn 0.5s ease;
}
.splash-logo {
    width: 72px; height: 72px;
    background: linear-gradient(135deg, #10a37f, #1a7f64);
    border-radius: 20px;
    display: flex; align-items: center; justify-content: center;
    margin-bottom: 20px;
    box-shadow: 0 0 40px rgba(16,163,127,0.4);
    animation: logoPulse 2s ease-in-out infinite;
}
.splash-logo svg { width: 40px; height: 40px; }
.splash-title { font-size: 28px; font-weight: 700; color: #fff; letter-spacing: -0.5px; }
.splash-sub { font-size: 13px; color: #6b6b6b; margin-top: 6px; }
.splash-loader {
    margin-top: 40px;
    display: flex; gap: 6px;
}
.splash-dot {
    width: 8px; height: 8px; border-radius: 50%;
    background: #10a37f;
    animation: dotBounce 1.2s ease-in-out infinite;
}
.splash-dot:nth-child(2) { animation-delay: 0.2s; }
.splash-dot:nth-child(3) { animation-delay: 0.4s; }

/* ── WELCOME ── */
.screen-welcome {
    display: flex; flex-direction: column;
    height: 100%; background: #0d0d0d;
    animation: slideUp 0.4s ease;
}
.welcome-hero {
    flex: 1; display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    padding: 40px 24px;
    background: linear-gradient(180deg, #0d0d0d 0%, #111 100%);
}
.welcome-icon-row {
    display: flex; gap: 10px; margin-bottom: 32px;
}
.welcome-chip {
    background: #1a1a1a; border: 1px solid #2a2a2a;
    border-radius: 10px; padding: 8px 14px;
    font-size: 11px; color: #8a8a8a; font-weight: 500;
    display: flex; align-items: center; gap: 5px;
}
.welcome-chip .dot { width: 6px; height: 6px; border-radius: 50%; background: #10a37f; }
.welcome-tagline {
    font-size: 22px; font-weight: 700; text-align: center;
    color: #fff; line-height: 1.3; margin-bottom: 12px;
    letter-spacing: -0.3px;
}
.welcome-desc {
    font-size: 13px; color: #6b6b6b; text-align: center;
    line-height: 1.6; max-width: 280px;
}
.feature-list {
    display: flex; flex-direction: column; gap: 10px;
    padding: 0 24px; margin-bottom: 24px;
}
.feature-item {
    display: flex; align-items: center; gap: 12px;
    background: #161616; border: 1px solid #222;
    border-radius: 12px; padding: 12px 16px;
}
.feature-icon {
    width: 32px; height: 32px; border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    font-size: 16px; flex-shrink: 0;
}
.feature-icon.green { background: rgba(16,163,127,0.15); }
.feature-icon.blue  { background: rgba(99,102,241,0.15); }
.feature-icon.amber { background: rgba(245,158,11,0.15); }
.feature-text strong { display: block; font-size: 13px; color: #fff; font-weight: 600; }
.feature-text span   { font-size: 11px; color: #6b6b6b; }
.welcome-footer { padding: 0 24px 32px; display: flex; flex-direction: column; gap: 10px; }
.btn-primary {
    width: 100%; padding: 14px; border: none; border-radius: 12px;
    background: #10a37f; color: #fff; font-size: 15px; font-weight: 600;
    cursor: pointer; transition: all 0.2s;
    font-family: inherit;
}
.btn-primary:hover { background: #0e8f6e; transform: translateY(-1px); }
.btn-primary:active { transform: translateY(0); }
.btn-secondary {
    width: 100%; padding: 14px; border: 1px solid #2a2a2a; border-radius: 12px;
    background: transparent; color: #ececec; font-size: 15px; font-weight: 500;
    cursor: pointer; transition: all 0.2s; font-family: inherit;
}
.btn-secondary:hover { background: #1a1a1a; }
.btn-link {
    background: none; border: none; color: #6b6b6b;
    font-size: 12px; cursor: pointer; font-family: inherit;
    text-decoration: underline; margin-top: 4px;
}

/* ── LOGIN ── */
.screen-login {
    display: flex; flex-direction: column; height: 100%;
    background: #0d0d0d; animation: slideUp 0.35s ease;
}
.login-header {
    display: flex; align-items: center; gap: 12px;
    padding: 16px 20px; border-bottom: 1px solid #1a1a1a;
}
.back-btn {
    width: 32px; height: 32px; border-radius: 8px;
    background: #1a1a1a; border: none; color: #ececec;
    cursor: pointer; display: flex; align-items: center; justify-content: center;
    font-size: 16px;
}
.login-header h2 { font-size: 16px; font-weight: 600; color: #fff; }
.login-body { flex: 1; padding: 32px 24px; display: flex; flex-direction: column; gap: 20px; }
.login-logo-area { text-align: center; margin-bottom: 8px; }
.login-logo {
    width: 56px; height: 56px; border-radius: 16px;
    background: linear-gradient(135deg, #10a37f, #1a7f64);
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 12px; box-shadow: 0 0 30px rgba(16,163,127,0.3);
}
.login-logo svg { width: 30px; height: 30px; }
.login-title { font-size: 20px; font-weight: 700; color: #fff; }
.login-sub { font-size: 13px; color: #6b6b6b; margin-top: 4px; }

.role-selector { display: flex; gap: 8px; }
.role-btn {
    flex: 1; padding: 12px 8px; border-radius: 10px;
    border: 2px solid #222; background: #161616;
    color: #8a8a8a; font-size: 13px; font-weight: 600;
    cursor: pointer; transition: all 0.2s; font-family: inherit;
    text-align: center;
}
.role-btn.active { border-color: #10a37f; background: rgba(16,163,127,0.12); color: #10a37f; }
.role-btn .role-emoji { display: block; font-size: 20px; margin-bottom: 4px; }

.field-group { display: flex; flex-direction: column; gap: 6px; }
.field-label { font-size: 12px; color: #8a8a8a; font-weight: 500; }
.field-input {
    width: 100%; padding: 13px 14px; background: #161616;
    border: 1px solid #2a2a2a; border-radius: 10px;
    color: #ececec; font-size: 14px; outline: none;
    transition: border-color 0.2s; font-family: inherit;
}
.field-input:focus { border-color: #10a37f; }
.field-input::placeholder { color: #3a3a3a; }

.divider { display: flex; align-items: center; gap: 10px; color: #3a3a3a; font-size: 12px; }
.divider::before, .divider::after { content: ''; flex: 1; height: 1px; background: #222; }

.btn-google {
    width: 100%; padding: 13px; border: 1px solid #2a2a2a; border-radius: 10px;
    background: #161616; color: #ececec; font-size: 14px; font-weight: 500;
    cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 10px;
    transition: all 0.2s; font-family: inherit;
}
.btn-google:hover { background: #1e1e1e; border-color: #333; }

/* ── CHAT ── */
.screen-chat {
    display: flex; flex-direction: column; height: 100%;
    background: #0d0d0d; animation: fadeIn 0.3s ease;
}
.chat-header {
    display: flex; align-items: center; justify-content: space-between;
    padding: 14px 16px; border-bottom: 1px solid #1a1a1a;
    background: #0d0d0d; flex-shrink: 0;
}
.chat-header-left { display: flex; align-items: center; gap: 10px; }
.agent-avatar {
    width: 36px; height: 36px; border-radius: 10px;
    background: linear-gradient(135deg, #10a37f, #1a7f64);
    display: flex; align-items: center; justify-content: center;
}
.agent-avatar svg { width: 20px; height: 20px; }
.agent-info strong { display: block; font-size: 14px; font-weight: 600; color: #fff; }
.agent-info span { font-size: 11px; color: #10a37f; }
.header-actions { display: flex; gap: 8px; }
.icon-btn {
    width: 32px; height: 32px; border-radius: 8px;
    background: #1a1a1a; border: none; color: #8a8a8a;
    cursor: pointer; display: flex; align-items: center; justify-content: center;
    transition: all 0.15s; font-size: 14px;
}
.icon-btn:hover { background: #222; color: #ececec; }

.messages-area {
    flex: 1; overflow-y: auto; padding: 16px;
    display: flex; flex-direction: column; gap: 8px;
    scroll-behavior: smooth;
}
.messages-area::-webkit-scrollbar { width: 0; }

.msg-row { display: flex; align-items: flex-end; gap: 8px; max-width: 100%; }
.msg-row.user { flex-direction: row-reverse; }

.msg-avatar {
    width: 28px; height: 28px; border-radius: 8px; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center; font-size: 13px;
}
.msg-avatar.bot { background: linear-gradient(135deg, #10a37f, #1a7f64); }
.msg-avatar.bot svg { width: 16px; height: 16px; }
.msg-avatar.user-av { background: #1e3a8a; font-weight: 600; color: #93c5fd; font-size: 11px; }

.msg-bubble {
    max-width: 75%; padding: 10px 14px;
    border-radius: 16px; font-size: 13.5px; line-height: 1.55;
    position: relative;
}
.msg-bubble.bot {
    background: #1a1a1a; color: #ececec; border-bottom-left-radius: 4px;
    border: 1px solid #222;
}
.msg-bubble.user {
    background: #10a37f; color: #fff; border-bottom-right-radius: 4px;
}
.msg-time { font-size: 10px; color: #4a4a4a; margin-top: 4px; display: block; }
.msg-row.user .msg-time { text-align: right; }

/* Typing indicator */
.typing-bubble {
    display: flex; gap: 4px; align-items: center;
    background: #1a1a1a; border: 1px solid #222;
    padding: 12px 16px; border-radius: 16px; border-bottom-left-radius: 4px;
    width: fit-content;
}
.typing-dot {
    width: 7px; height: 7px; border-radius: 50%; background: #6b6b6b;
    animation: typingBounce 1.2s ease-in-out infinite;
}
.typing-dot:nth-child(2) { animation-delay: 0.2s; }
.typing-dot:nth-child(3) { animation-delay: 0.4s; }

/* Suggestion chips */
.suggestion-row {
    display: flex; gap: 6px; flex-wrap: nowrap;
    overflow-x: auto; padding: 8px 16px 0;
    flex-shrink: 0;
}
.suggestion-row::-webkit-scrollbar { height: 0; }
.chip {
    flex-shrink: 0; padding: 8px 14px;
    background: #161616; border: 1px solid #2a2a2a;
    border-radius: 20px; color: #8a8a8a; font-size: 12px;
    cursor: pointer; white-space: nowrap; transition: all 0.15s;
    font-family: inherit;
}
.chip:hover { background: #1e1e1e; border-color: #10a37f; color: #10a37f; }

/* Input area */
.chat-input-area {
    padding: 10px 12px 20px; background: #0d0d0d;
    border-top: 1px solid #1a1a1a; flex-shrink: 0;
}
.input-box {
    display: flex; align-items: flex-end; gap: 8px;
    background: #161616; border: 1px solid #2a2a2a;
    border-radius: 16px; padding: 8px 8px 8px 14px;
    transition: border-color 0.2s;
}
.input-box:focus-within { border-color: #333; }
.chat-textarea {
    flex: 1; background: none; border: none; outline: none;
    color: #ececec; font-size: 14px; font-family: inherit;
    resize: none; min-height: 24px; max-height: 120px;
    line-height: 1.5; padding: 3px 0;
}
.chat-textarea::placeholder { color: #3a3a3a; }
.input-actions { display: flex; gap: 4px; align-items: center; }
.mic-btn, .send-btn {
    width: 36px; height: 36px; border-radius: 10px;
    border: none; cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    transition: all 0.15s; flex-shrink: 0;
}
.mic-btn { background: #1a1a1a; color: #6b6b6b; }
.mic-btn:hover { background: #222; color: #ececec; }
.mic-btn.recording { background: rgba(239,68,68,0.15); color: #ef4444; animation: micPulse 1s ease-in-out infinite; }
.send-btn { background: #10a37f; color: #fff; }
.send-btn:hover { background: #0e8f6e; }
.send-btn:disabled { background: #1a1a1a; color: #3a3a3a; cursor: default; }

/* ── ADMIN ── */
.screen-admin {
    display: flex; flex-direction: column; height: 100%;
    background: #0d0d0d; animation: fadeIn 0.3s ease;
}
.admin-header {
    display: flex; align-items: center; justify-content: space-between;
    padding: 14px 16px; border-bottom: 1px solid #1a1a1a;
    background: #0d0d0d;
}
.admin-header-left { display: flex; align-items: center; gap: 10px; }
.admin-avatar {
    width: 36px; height: 36px; border-radius: 10px;
    background: linear-gradient(135deg, #6366f1, #4f46e5);
    display: flex; align-items: center; justify-content: center; font-size: 18px;
}
.admin-info strong { display: block; font-size: 14px; font-weight: 600; color: #fff; }
.admin-info span { font-size: 11px; color: #6366f1; }

.admin-body { flex: 1; overflow-y: auto; display: flex; flex-direction: column; }
.admin-body::-webkit-scrollbar { width: 0; }

.admin-tabs {
    display: flex; border-bottom: 1px solid #1a1a1a; flex-shrink: 0;
}
.tab-btn {
    flex: 1; padding: 12px 8px; border: none;
    background: none; color: #6b6b6b; font-size: 12px;
    font-weight: 600; cursor: pointer; font-family: inherit;
    border-bottom: 2px solid transparent; transition: all 0.2s;
    text-transform: uppercase; letter-spacing: 0.5px;
}
.tab-btn.active { color: #6366f1; border-bottom-color: #6366f1; }

.tab-content { flex: 1; overflow-y: auto; padding: 16px; }
.tab-content::-webkit-scrollbar { width: 0; }

.quick-cmd-grid {
    display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 20px;
}
.quick-cmd {
    padding: 12px; background: #161616; border: 1px solid #222;
    border-radius: 12px; cursor: pointer; transition: all 0.15s;
    text-align: center;
}
.quick-cmd:hover { border-color: #6366f1; background: rgba(99,102,241,0.08); }
.quick-cmd .cmd-emoji { font-size: 22px; display: block; margin-bottom: 6px; }
.quick-cmd .cmd-label { font-size: 11px; color: #8a8a8a; font-weight: 500; }

.section-label { font-size: 11px; color: #4a4a4a; font-weight: 600; text-transform: uppercase; letter-spacing: 0.8px; margin-bottom: 10px; }

.admin-input-area { padding: 10px 16px 20px; border-top: 1px solid #1a1a1a; }
.admin-input-box {
    display: flex; align-items: flex-end; gap: 8px;
    background: #161616; border: 1px solid #2a2a2a;
    border-radius: 16px; padding: 8px 8px 8px 14px;
}
.admin-textarea {
    flex: 1; background: none; border: none; outline: none;
    color: #ececec; font-size: 14px; font-family: inherit;
    resize: none; min-height: 24px; max-height: 100px; line-height: 1.5; padding: 3px 0;
}
.admin-textarea::placeholder { color: #3a3a3a; }
.submit-btn {
    width: 36px; height: 36px; border-radius: 10px;
    background: #6366f1; border: none; color: #fff;
    cursor: pointer; display: flex; align-items: center; justify-content: center;
    transition: all 0.15s; flex-shrink: 0;
}
.submit-btn:hover { background: #4f46e5; }

.log-entry {
    background: #161616; border: 1px solid #222;
    border-radius: 12px; padding: 12px 14px; margin-bottom: 8px;
}
.log-entry.success { border-left: 3px solid #10a37f; }
.log-entry.pending { border-left: 3px solid #f59e0b; }
.log-entry.error   { border-left: 3px solid #ef4444; }
.log-cmd { font-size: 13px; color: #ececec; font-weight: 500; margin-bottom: 4px; }
.log-resp { font-size: 12px; color: #6b6b6b; margin-top: 4px; }
.log-meta { display: flex; justify-content: space-between; align-items: center; margin-top: 6px; }
.log-time { font-size: 10px; color: #4a4a4a; }
.log-badge {
    font-size: 10px; font-weight: 600; padding: 2px 8px; border-radius: 10px;
    text-transform: uppercase; letter-spacing: 0.5px;
}
.log-badge.success { background: rgba(16,163,127,0.15); color: #10a37f; }
.log-badge.pending { background: rgba(245,158,11,0.15); color: #f59e0b; }
.log-badge.error   { background: rgba(239,68,68,0.15); color: #ef4444; }

.empty-state {
    display: flex; flex-direction: column; align-items: center;
    justify-content: center; padding: 40px 20px; color: #3a3a3a; text-align: center;
}
.empty-state .empty-icon { font-size: 40px; margin-bottom: 12px; }
.empty-state p { font-size: 13px; line-height: 1.6; }

/* ── ANIMATIONS ── */
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
@keyframes logoPulse { 0%,100% { box-shadow: 0 0 30px rgba(16,163,127,0.4); } 50% { box-shadow: 0 0 50px rgba(16,163,127,0.7); } }
@keyframes dotBounce { 0%,80%,100% { transform: translateY(0); } 40% { transform: translateY(-8px); } }
@keyframes typingBounce { 0%,60%,100% { transform: translateY(0); } 30% { transform: translateY(-6px); } }
@keyframes micPulse { 0%,100% { box-shadow: 0 0 0 0 rgba(239,68,68,0.4); } 50% { box-shadow: 0 0 0 8px rgba(239,68,68,0); } }
@keyframes msgIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
.msg-row { animation: msgIn 0.25s ease; }
`;

// ─── SVG Icons ────────────────────────────────────────────────────────────────

const ICONS = {
    logo: `<svg viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
    mic: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>`,
    send: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>`,
    menu: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>`,
    back: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>`,
    google: `<svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>`,
    refresh: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>`,
    data: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>`,
};

// ─── Bot Responses ─────────────────────────────────────────────────────────────

const STUDENT_RESPONSES: Record<string, string> = {
    default: "I'm here to help! You can ask me about your schedule, class locations, trainer info, or placement drives. Try asking: *Where is today's Python class?*",
    schedule: "📅 **Today's Schedule (Batch A):**\n• 9:00 AM – Python (Room 201, Trainer: Mr. Ravi)\n• 11:00 AM – Flutter (Bay-3, Trainer: Ms. Priya)\n• 2:00 PM – AWS (Lab-5, Trainer: Mr. Kumar)",
    room: "📍 **Room Update:** Flutter class has been **moved to Bay-3** today. The regular schedule shows Room 102, but an emergency update is in effect.",
    trainer: "👤 **Trainer Info:**\n• Python → Mr. Ravi Shankar\n• Flutter → Ms. Priya Mehta\n• AWS → Mr. Kumar Reddy\n• React → Ms. Anita Sharma",
    placement: "🏢 **Upcoming Placement Drives:**\n• TCS – May 12 (CSE, ECE branches)\n• Infosys – May 18 (All branches)\n• Wipro – May 25 (BE/BTech 65%+)\n\nRegister at the placement cell portal.",
    update: "⚡ **Emergency Updates Today:**\n• Flutter class moved to Bay-3\n• ML session cancelled (trainer unwell)\n• Extra Python lab added at 4:00 PM\n\n*Last updated: 2 min ago*",
    cancel: "❌ **Cancellation Notice:** ML session scheduled for 3:00 PM has been cancelled today. Alternative self-study material has been shared on the portal.",
};

const ADMIN_RESPONSES: Record<string, string> = {
    default: "✅ Command received. Processing your schedule update...",
    move: "✅ **Update Applied:** Room change recorded successfully in Dataverse. All students in the batch have been notified via the Student Agent.",
    cancel: "✅ **Cancellation Recorded:** Session marked as cancelled. Emergency update stored. Student notifications queued in Power Automate.",
    batch: "✅ **Batch Update:** No-class rule applied to DRIVE READY batch. Dataverse Emergency Updates table has been updated with start/end dates.",
    error: "⚠️ **Partial Success:** Update recorded in Dataverse, but notification flow encountered an issue. Please verify Power Automate flow status.",
};

// ─── Main Component Class ─────────────────────────────────────────────────────

export class CampusAIApp implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private container!: HTMLDivElement;
    private state: AppState;
    private recordingTimer?: ReturnType<typeof setTimeout>;
    private speechRecognition?: SpeechRecognition;
    private activeAdminTab: "commands" | "log" = "commands";

    constructor() {
        this.state = {
            screen: "splash",
            userRole: "guest",
            userName: "",
            messages: [],
            adminLog: [],
            isTyping: false,
            inputValue: "",
            agentEndpoint: "",
            adminFlowUrl: "",
            notifyOutputChanged: () => {},
            lastMessage: "",
            activeScreen: "splash",
        };
    }

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        _state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        this.container = container;
        this.state.notifyOutputChanged = notifyOutputChanged;
        this.state.agentEndpoint = context.parameters.agentEndpoint?.raw || "";
        this.state.adminFlowUrl = context.parameters.adminFlowUrl?.raw || "";

        // If Power Apps passes a role/user, skip to chat
        const boundRole = context.parameters.userRole?.raw;
        const boundName = context.parameters.userName?.raw;
        if (boundRole && boundRole !== "guest" && boundName) {
            this.state.userRole = boundRole as "student" | "admin";
            this.state.userName = boundName;
        }

        this.injectStyles();
        this.render();

        // Auto-advance splash after 2s
        setTimeout(() => {
            this.navigate("welcome");
        }, 2000);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        const role = context.parameters.userRole?.raw;
        const name = context.parameters.userName?.raw;
        if (role && name && (role !== this.state.userRole || name !== this.state.userName)) {
            this.state.userRole = role as "student" | "admin";
            this.state.userName = name;
            this.navigate(role === "admin" ? "admin" : "chat");
        }
    }

    public getOutputs(): IOutputs {
        return {
            lastMessage: this.state.lastMessage,
            activeScreen: this.state.activeScreen,
            userRole: this.state.userRole,
            userName: this.state.userName,
        };
    }

    public destroy(): void {
        if (this.recordingTimer) clearTimeout(this.recordingTimer);
    }

    // ─── Navigation ─────────────────────────────────────────────────────────

    private navigate(screen: Screen): void {
        this.state.screen = screen;
        this.state.activeScreen = screen;
        if (screen === "chat" && this.state.messages.length === 0) {
            this.addBotMessage(
                `Hey ${this.state.userName || "there"} 👋 I'm your Campus AI Student Agent. Ask me anything about your schedule, classes, or placement drives!`
            );
        }
        this.render();
        this.state.notifyOutputChanged();
    }

    // ─── Render ─────────────────────────────────────────────────────────────

    private render(): void {
        const root = document.getElementById("campus-root");
        if (!root) {
            this.container.innerHTML = `<div id="campus-root" class="campus-root"></div>`;
        }
        const el = this.container.querySelector("#campus-root") as HTMLDivElement;
        if (!el) return;

        switch (this.state.screen) {
            case "splash":   el.innerHTML = this.renderSplash(); break;
            case "welcome":  el.innerHTML = this.renderWelcome(); this.bindWelcome(el); break;
            case "login":    el.innerHTML = this.renderLogin(); this.bindLogin(el); break;
            case "chat":     el.innerHTML = this.renderChat(); this.bindChat(el); break;
            case "admin":    el.innerHTML = this.renderAdmin(); this.bindAdmin(el); break;
        }
    }

    // ─── Screens ────────────────────────────────────────────────────────────

    private renderSplash(): string {
        return `
        <div class="screen-splash">
            <div class="splash-logo">${ICONS.logo}</div>
            <div class="splash-title">Campus AI</div>
            <div class="splash-sub">Intelligent Campus Assistant</div>
            <div class="splash-loader">
                <div class="splash-dot"></div>
                <div class="splash-dot"></div>
                <div class="splash-dot"></div>
            </div>
        </div>`;
    }

    private renderWelcome(): string {
        return `
        <div class="screen-welcome">
            <div class="welcome-hero">
                <div class="welcome-icon-row">
                    <div class="welcome-chip"><span class="dot"></span>Live</div>
                    <div class="welcome-chip">Power Platform</div>
                    <div class="welcome-chip">Copilot Studio</div>
                </div>
                <div class="welcome-tagline">The next era of<br>campus intelligence</div>
                <div class="welcome-desc">AI-powered schedule management, real-time updates, and smart campus communication.</div>
            </div>
            <div class="feature-list">
                <div class="feature-item">
                    <div class="feature-icon green">🗓️</div>
                    <div class="feature-text">
                        <strong>Real-time Schedule</strong>
                        <span>Emergency updates override instantly</span>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon blue">🤖</div>
                    <div class="feature-text">
                        <strong>AI Agents</strong>
                        <span>Natural language understanding via Copilot Studio</span>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon amber">🏢</div>
                    <div class="feature-text">
                        <strong>Placement Drives</strong>
                        <span>Stay updated on company visits</span>
                    </div>
                </div>
            </div>
            <div class="welcome-footer">
                <button class="btn-primary" id="btn-login">Log in or sign up</button>
                <button class="btn-secondary" id="btn-guest">Continue as guest</button>
            </div>
        </div>`;
    }

    private bindWelcome(el: HTMLElement): void {
        el.querySelector("#btn-login")?.addEventListener("click", () => this.navigate("login"));
        el.querySelector("#btn-guest")?.addEventListener("click", () => {
            this.state.userRole = "student";
            this.state.userName = "Guest";
            this.navigate("chat");
        });
    }

    private renderLogin(): string {
        return `
        <div class="screen-login">
            <div class="login-header">
                <button class="back-btn" id="btn-back">${ICONS.back}</button>
                <h2>Sign in</h2>
            </div>
            <div class="login-body">
                <div class="login-logo-area">
                    <div class="login-logo">${ICONS.logo}</div>
                    <div class="login-title">Log in or sign up</div>
                    <div class="login-sub">You'll get smarter responses and real-time campus data</div>
                </div>

                <div>
                    <div class="section-label" style="margin-bottom:8px">I am a</div>
                    <div class="role-selector">
                        <button class="role-btn active" id="role-student">
                            <span class="role-emoji">🎓</span>Student
                        </button>
                        <button class="role-btn" id="role-admin">
                            <span class="role-emoji">🛡️</span>Admin
                        </button>
                    </div>
                </div>

                <div class="field-group">
                    <label class="field-label">Email</label>
                    <input id="input-email" class="field-input" type="email" placeholder="you@college.edu" />
                </div>

                <button class="btn-primary" id="btn-continue">Continue</button>

                <div class="divider">or</div>

                <button class="btn-google" id="btn-google">
                    ${ICONS.google} Continue with Google
                </button>

                <button class="btn-link" id="btn-phone">Continue with phone</button>
            </div>
        </div>`;
    }

    private bindLogin(el: HTMLElement): void {
        let selectedRole: "student" | "admin" = "student";

        el.querySelector("#btn-back")?.addEventListener("click", () => this.navigate("welcome"));

        const studentBtn = el.querySelector("#role-student") as HTMLButtonElement;
        const adminBtn   = el.querySelector("#role-admin") as HTMLButtonElement;

        studentBtn.addEventListener("click", () => {
            selectedRole = "student";
            studentBtn.classList.add("active");
            adminBtn.classList.remove("active");
        });
        adminBtn.addEventListener("click", () => {
            selectedRole = "admin";
            adminBtn.classList.add("active");
            studentBtn.classList.remove("active");
        });

        const doLogin = () => {
            const email = (el.querySelector("#input-email") as HTMLInputElement)?.value;
            this.state.userRole = selectedRole;
            this.state.userName = email ? email.split("@")[0] : (selectedRole === "admin" ? "Admin" : "Student");
            this.navigate(selectedRole === "admin" ? "admin" : "chat");
        };

        el.querySelector("#btn-continue")?.addEventListener("click", doLogin);
        el.querySelector("#btn-google")?.addEventListener("click", doLogin);
        el.querySelector("#btn-phone")?.addEventListener("click", doLogin);
        (el.querySelector("#input-email") as HTMLInputElement)?.addEventListener("keydown", (e) => {
            if ((e as KeyboardEvent).key === "Enter") doLogin();
        });
    }

    private renderChat(): string {
        const msgs = this.state.messages.map(m => {
            if (m.role === "assistant") {
                return `
                <div class="msg-row">
                    <div class="msg-avatar bot">${ICONS.logo}</div>
                    <div>
                        <div class="msg-bubble bot">${this.formatText(m.text)}</div>
                        <span class="msg-time">${m.time}</span>
                    </div>
                </div>`;
            } else {
                const initials = (this.state.userName || "U").slice(0, 2).toUpperCase();
                return `
                <div class="msg-row user">
                    <div class="msg-avatar user-av">${initials}</div>
                    <div>
                        <div class="msg-bubble user">${this.escapeHtml(m.text)}</div>
                        <span class="msg-time">${m.time}</span>
                    </div>
                </div>`;
            }
        }).join("");

        const typing = this.state.isTyping ? `
        <div class="msg-row" id="typing-indicator">
            <div class="msg-avatar bot">${ICONS.logo}</div>
            <div class="typing-bubble">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        </div>` : "";

        return `
        <div class="screen-chat">
            <div class="chat-header">
                <div class="chat-header-left">
                    <div class="agent-avatar">${ICONS.logo}</div>
                    <div class="agent-info">
                        <strong>Campus AI</strong>
                        <span>● Student Agent</span>
                    </div>
                </div>
                <div class="header-actions">
                    <button class="icon-btn" id="btn-refresh" title="New chat">${ICONS.refresh}</button>
                    <button class="icon-btn" id="btn-data" title="Data">${ICONS.data}</button>
                    <button class="icon-btn" id="btn-admin-switch" title="Menu">${ICONS.menu}</button>
                </div>
            </div>

            <div class="messages-area" id="messages-area">
                ${msgs || `<div class="empty-state"><div class="empty-icon">🤖</div><p>Ask me about schedules,<br>classes, or placement drives</p></div>`}
                ${typing}
            </div>

            <div class="suggestion-row" id="suggestion-row">
                <button class="chip" data-msg="What's my schedule today?">📅 Today's schedule</button>
                <button class="chip" data-msg="Any emergency updates?">⚡ Updates</button>
                <button class="chip" data-msg="Where is Flutter class?">📍 Find class</button>
                <button class="chip" data-msg="Any placement drives this week?">🏢 Placements</button>
            </div>

            <div class="chat-input-area">
                <div class="input-box">
                    <textarea
                        id="chat-input"
                        class="chat-textarea"
                        placeholder="Ask Campus AI..."
                        rows="1"
                    ></textarea>
                    <div class="input-actions">
                        <button class="mic-btn" id="mic-btn" title="Voice input">${ICONS.mic}</button>
                        <button class="send-btn" id="send-btn" disabled title="Send">${ICONS.send}</button>
                    </div>
                </div>
            </div>
        </div>`;
    }

    private bindChat(el: HTMLElement): void {
        const textarea = el.querySelector("#chat-input") as HTMLTextAreaElement;
        const sendBtn  = el.querySelector("#send-btn") as HTMLButtonElement;
        const micBtn   = el.querySelector("#mic-btn") as HTMLButtonElement;

        // Auto-resize textarea
        textarea.addEventListener("input", () => {
            textarea.style.height = "auto";
            textarea.style.height = Math.min(textarea.scrollHeight, 120) + "px";
            sendBtn.disabled = textarea.value.trim().length === 0;
            this.state.inputValue = textarea.value;
        });

        textarea.addEventListener("keydown", (e) => {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                if (!sendBtn.disabled) this.sendStudentMessage(textarea.value.trim(), el);
            }
        });

        sendBtn.addEventListener("click", () => {
            if (textarea.value.trim()) this.sendStudentMessage(textarea.value.trim(), el);
        });

        // Chips
        el.querySelectorAll(".chip[data-msg]").forEach(chip => {
            chip.addEventListener("click", () => {
                const msg = (chip as HTMLElement).dataset.msg || "";
                this.sendStudentMessage(msg, el);
            });
        });

        // Mic
        micBtn.addEventListener("click", () => this.handleMicClick(micBtn, textarea, sendBtn));

        // Refresh
        el.querySelector("#btn-refresh")?.addEventListener("click", () => {
            this.state.messages = [];
            this.navigate("chat");
        });

        // Switch to admin (if admin user)
        el.querySelector("#btn-admin-switch")?.addEventListener("click", () => {
            if (this.state.userRole === "admin") {
                this.navigate("admin");
            } else {
                this.navigate("welcome");
            }
        });

        // Scroll to bottom
        setTimeout(() => {
            const area = el.querySelector("#messages-area");
            if (area) area.scrollTop = area.scrollHeight;
        }, 50);
    }

    private renderAdmin(): string {
        const isCommands = this.activeAdminTab === "commands";

        const quickCmds = [
            { emoji: "🔄", label: "Move Room", cmd: "Move [class] to [room]" },
            { emoji: "❌", label: "Cancel Class", cmd: "Cancel today's [class] session" },
            { emoji: "📅", label: "No Classes", cmd: "No classes for [batch] on [date]" },
            { emoji: "🏢", label: "Add Drive", cmd: "Add placement drive: [company] on [date]" },
        ].map(q => `
            <div class="quick-cmd" data-cmd="${q.cmd}">
                <span class="cmd-emoji">${q.emoji}</span>
                <span class="cmd-label">${q.label}</span>
            </div>
        `).join("");

        const logEntries = this.state.adminLog.length === 0
            ? `<div class="empty-state"><div class="empty-icon">📋</div><p>No commands yet.<br>Use the Commands tab to send updates.</p></div>`
            : this.state.adminLog.map(entry => `
                <div class="log-entry ${entry.status}">
                    <div class="log-cmd">${this.escapeHtml(entry.command)}</div>
                    <div class="log-resp">${entry.response}</div>
                    <div class="log-meta">
                        <span class="log-time">${entry.time}</span>
                        <span class="log-badge ${entry.status}">${entry.status}</span>
                    </div>
                </div>
            `).join("");

        return `
        <div class="screen-admin">
            <div class="admin-header">
                <div class="admin-header-left">
                    <div class="admin-avatar">🛡️</div>
                    <div class="admin-info">
                        <strong>${this.escapeHtml(this.state.userName || "Admin")}</strong>
                        <span>● Admin Agent</span>
                    </div>
                </div>
                <div class="header-actions">
                    <button class="icon-btn" id="btn-switch-student" title="Switch to Student View">${ICONS.logo}</button>
                    <button class="icon-btn" id="btn-signout" title="Sign out">${ICONS.back}</button>
                </div>
            </div>

            <div class="admin-body">
                <div class="admin-tabs">
                    <button class="tab-btn ${isCommands ? "active" : ""}" id="tab-commands">⚡ Commands</button>
                    <button class="tab-btn ${!isCommands ? "active" : ""}" id="tab-log">📋 Log (${this.state.adminLog.length})</button>
                </div>

                <div class="tab-content" id="tab-content">
                    ${isCommands ? `
                        <div class="section-label" style="margin-bottom:10px">Quick Commands</div>
                        <div class="quick-cmd-grid">${quickCmds}</div>
                        <div class="section-label">Type a custom command</div>
                        <div style="font-size:11px;color:#4a4a4a;margin-top:4px;margin-bottom:12px">Use natural language – the Admin Agent understands context</div>
                        <div style="display:flex;flex-direction:column;gap:6px">
                            <div style="background:#161616;border:1px solid #222;border-radius:10px;padding:10px 14px;font-size:12px;color:#6b6b6b">
                                <span style="color:#f59e0b">Example:</span> "Move Flutter class to Bay-3 for all batches today"
                            </div>
                            <div style="background:#161616;border:1px solid #222;border-radius:10px;padding:10px 14px;font-size:12px;color:#6b6b6b">
                                <span style="color:#f59e0b">Example:</span> "No classes for DRIVE READY batch from May 12 to May 14"
                            </div>
                        </div>
                    ` : `
                        <div class="section-label" style="margin-bottom:10px">Command History</div>
                        ${logEntries}
                    `}
                </div>
            </div>

            <div class="admin-input-area">
                <div class="admin-input-box">
                    <textarea
                        id="admin-input"
                        class="admin-textarea"
                        placeholder="Type admin command..."
                        rows="1"
                    ></textarea>
                    <div class="input-actions">
                        <button class="mic-btn" id="admin-mic-btn">${ICONS.mic}</button>
                        <button class="submit-btn" id="admin-submit-btn">${ICONS.send}</button>
                    </div>
                </div>
            </div>
        </div>`;
    }

    private bindAdmin(el: HTMLElement): void {
        const textarea  = el.querySelector("#admin-input") as HTMLTextAreaElement;
        const submitBtn = el.querySelector("#admin-submit-btn") as HTMLButtonElement;
        const micBtn    = el.querySelector("#admin-mic-btn") as HTMLButtonElement;

        textarea.addEventListener("input", () => {
            textarea.style.height = "auto";
            textarea.style.height = Math.min(textarea.scrollHeight, 100) + "px";
        });

        textarea.addEventListener("keydown", (e) => {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                if (textarea.value.trim()) this.sendAdminCommand(textarea.value.trim());
            }
        });

        submitBtn.addEventListener("click", () => {
            if (textarea.value.trim()) this.sendAdminCommand(textarea.value.trim());
        });

        // Quick cmd grid
        el.querySelectorAll(".quick-cmd[data-cmd]").forEach(btn => {
            btn.addEventListener("click", () => {
                const cmd = (btn as HTMLElement).dataset.cmd || "";
                textarea.value = cmd;
                textarea.focus();
                textarea.selectionStart = textarea.selectionEnd = cmd.length;
            });
        });

        // Tabs
        el.querySelector("#tab-commands")?.addEventListener("click", () => {
            this.activeAdminTab = "commands";
            this.navigate("admin");
        });
        el.querySelector("#tab-log")?.addEventListener("click", () => {
            this.activeAdminTab = "log";
            this.navigate("admin");
        });

        // Switch / signout
        el.querySelector("#btn-switch-student")?.addEventListener("click", () => this.navigate("chat"));
        el.querySelector("#btn-signout")?.addEventListener("click", () => {
            this.state.messages = [];
            this.state.adminLog = [];
            this.state.userName = "";
            this.navigate("welcome");
        });

        // Mic
        micBtn.addEventListener("click", () => {
            const fakeSendBtn = { classList: { add: () => {}, remove: () => {} }, disabled: false } as unknown as HTMLButtonElement;
            this.handleMicClick(micBtn, textarea, fakeSendBtn);
        });
    }

    // ─── Logic ──────────────────────────────────────────────────────────────

    private sendStudentMessage(text: string, el: HTMLElement): void {
        if (!text) return;

        this.state.messages.push({ id: uid(), role: "user", text, time: now(), status: "sent" });
        this.state.lastMessage = text;
        this.state.isTyping = true;

        const textarea = el.querySelector("#chat-input") as HTMLTextAreaElement;
        if (textarea) { textarea.value = ""; textarea.style.height = "auto"; }
        const sendBtn = el.querySelector("#send-btn") as HTMLButtonElement;
        if (sendBtn) sendBtn.disabled = true;

        this.renderMessages(el);
        this.state.notifyOutputChanged();

        // Simulate agent response (replace with real Copilot Studio DirectLine call)
        const delay = 800 + Math.random() * 600;
        setTimeout(() => {
            this.state.isTyping = false;
            const response = this.getStudentResponse(text);
            this.state.messages.push({ id: uid(), role: "assistant", text: response, time: now(), status: "sent" });
            this.renderMessages(el);
        }, delay);
    }

    private sendAdminCommand(cmd: string): void {
        const entry: AdminEntry = {
            id: uid(),
            command: cmd,
            status: "pending",
            time: now(),
            response: "Processing command with Admin Agent...",
        };
        this.state.adminLog.unshift(entry);
        this.activeAdminTab = "log";
        this.navigate("admin");

        // Simulate Power Automate flow call
        setTimeout(() => {
            const idx = this.state.adminLog.findIndex(e => e.id === entry.id);
            if (idx !== -1) {
                const isError = Math.random() < 0.1;
                this.state.adminLog[idx].status = isError ? "error" : "success";
                this.state.adminLog[idx].response = this.getAdminResponse(cmd, isError);
            }
            this.navigate("admin");
        }, 1500);
    }

    private getStudentResponse(text: string): string {
        const t = text.toLowerCase();
        if (t.includes("schedule") || t.includes("today") || t.includes("timetable")) return STUDENT_RESPONSES.schedule;
        if (t.includes("room") || t.includes("where") || t.includes("flutter") || t.includes("bay")) return STUDENT_RESPONSES.room;
        if (t.includes("trainer") || t.includes("teacher") || t.includes("faculty") || t.includes("who")) return STUDENT_RESPONSES.trainer;
        if (t.includes("placement") || t.includes("drive") || t.includes("company") || t.includes("tcs") || t.includes("infosys")) return STUDENT_RESPONSES.placement;
        if (t.includes("update") || t.includes("emergency") || t.includes("change") || t.includes("latest")) return STUDENT_RESPONSES.update;
        if (t.includes("cancel")) return STUDENT_RESPONSES.cancel;
        return STUDENT_RESPONSES.default;
    }

    private getAdminResponse(cmd: string, error: boolean): string {
        if (error) return ADMIN_RESPONSES.error;
        const t = cmd.toLowerCase();
        if (t.includes("move") || t.includes("room") || t.includes("bay")) return ADMIN_RESPONSES.move;
        if (t.includes("cancel")) return ADMIN_RESPONSES.cancel;
        if (t.includes("batch") || t.includes("no class")) return ADMIN_RESPONSES.batch;
        return ADMIN_RESPONSES.default;
    }

    private handleMicClick(micBtn: HTMLButtonElement, textarea: HTMLTextAreaElement, sendBtn: HTMLButtonElement): void {
        const SpeechRecognitionAPI = (window as Window & { webkitSpeechRecognition?: typeof SpeechRecognition }).webkitSpeechRecognition || (window as Window & { SpeechRecognition?: typeof SpeechRecognition }).SpeechRecognition;

        if (!SpeechRecognitionAPI) {
            textarea.placeholder = "🎤 Voice not supported";
            setTimeout(() => { textarea.placeholder = "Ask Campus AI..."; }, 2000);
            return;
        }

        if (this.speechRecognition) {
            this.speechRecognition.stop();
            this.speechRecognition = undefined;
            micBtn.classList.remove("recording");
            return;
        }

        this.speechRecognition = new SpeechRecognitionAPI();
        this.speechRecognition.continuous = false;
        this.speechRecognition.interimResults = true;
        this.speechRecognition.lang = "en-US";

        micBtn.classList.add("recording");

        this.speechRecognition.onresult = (event: SpeechRecognitionEvent) => {
            const transcript = Array.from(event.results).map(r => r[0].transcript).join("");
            textarea.value = transcript;
            sendBtn.disabled = false;
        };

        this.speechRecognition.onend = () => {
            micBtn.classList.remove("recording");
            this.speechRecognition = undefined;
        };

        this.speechRecognition.onerror = () => {
            micBtn.classList.remove("recording");
            this.speechRecognition = undefined;
        };

        this.speechRecognition.start();
    }

    private renderMessages(el: HTMLElement): void {
        const area = el.querySelector("#messages-area");
        if (!area) return;

        const msgs = this.state.messages.map(m => {
            if (m.role === "assistant") {
                return `<div class="msg-row"><div class="msg-avatar bot">${ICONS.logo}</div><div><div class="msg-bubble bot">${this.formatText(m.text)}</div><span class="msg-time">${m.time}</span></div></div>`;
            }
            const initials = (this.state.userName || "U").slice(0, 2).toUpperCase();
            return `<div class="msg-row user"><div class="msg-avatar user-av">${initials}</div><div><div class="msg-bubble user">${this.escapeHtml(m.text)}</div><span class="msg-time">${m.time}</span></div></div>`;
        }).join("");

        const typing = this.state.isTyping ? `<div class="msg-row" id="typing-indicator"><div class="msg-avatar bot">${ICONS.logo}</div><div class="typing-bubble"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div></div>` : "";

        area.innerHTML = msgs + typing;
        area.scrollTop = area.scrollHeight;
    }

    // ─── Utilities ──────────────────────────────────────────────────────────

    private formatText(text: string): string {
        return text
            .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
            .replace(/\*(.*?)\*/g, "<em>$1</em>")
            .replace(/\n/g, "<br>");
    }

    private escapeHtml(text: string): string {
        return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    private addBotMessage(text: string): void {
        this.state.messages.push({ id: uid(), role: "assistant", text, time: now(), status: "sent" });
    }

    private injectStyles(): void {
        if (document.getElementById("campus-ai-styles")) return;
        const style = document.createElement("style");
        style.id = "campus-ai-styles";
        style.textContent = STYLES;
        document.head.appendChild(style);
        this.container.innerHTML = `<div id="campus-root" class="campus-root"></div>`;
    }
}

# Campus AI – PCF Component

A realistic ChatGPT-style Power Apps Component Framework (PCF) control for the Campus AI project.

## Screens

| Screen | Description |
|--------|-------------|
| **Splash** | App loading screen with animated dots |
| **Welcome** | Onboarding screen (like ChatGPT welcome) with feature highlights |
| **Login** | Role selector (Student / Admin) + email / Google login |
| **Chat** | Student Agent – conversational interface with mic, chips, typing indicator |
| **Admin** | Admin Agent – quick commands, custom NL input, command log |

## Setup in VS Code

```bash
# 1. Install PAC CLI (Power Platform CLI)
npm install -g @microsoft/pacx

# 2. Create the PCF project (already done)
pac pcf init --namespace CampusAI --name CampusAIApp --template field

# 3. Copy these files into your PCF project
# Replace: ControlManifest.Input.xml, index.ts
# Add:     generated/ManifestTypes.d.ts

# 4. Install dependencies
npm install

# 5. Start local dev server
npm start
```

## Properties (Power Apps)

| Property | Type | Usage | Description |
|----------|------|-------|-------------|
| `userRole` | SingleLine.Text | bound | `student` / `admin` / `guest` |
| `userName` | SingleLine.Text | bound | Display name of logged-in user |
| `agentEndpoint` | SingleLine.Text | bound | Copilot Studio Direct Line URL |
| `adminFlowUrl` | SingleLine.Text | bound | Power Automate flow URL |
| `lastMessage` | SingleLine.Text | output | Last message sent (triggers flows) |
| `activeScreen` | SingleLine.Text | output | Current screen name |

## Integrations

- **Copilot Studio** – Replace `getStudentResponse()` / `getAdminResponse()` with real Direct Line API calls to your bot endpoint.
- **Dataverse** – Connect via Power Automate flows triggered by `lastMessage` output property.
- **Power Automate** – Bind `adminFlowUrl` to your HTTP trigger flow URL for admin updates.

## Power Automate Flow Integration

```
lastMessage (output) → Power Apps trigger → 
  Parse message → Copilot Studio topic → 
    Dataverse upsert (Emergency Updates table)
```

## Building & Deploying

```bash
# Build for deployment
npm run build

# Push to your environment
pac pcf push --publisher-prefix campus
```

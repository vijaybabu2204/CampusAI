/*
 * CampusAI PCF — Auto-generated ManifestTypes
 * Do not edit manually. Regenerate with: pac pcf build
 */

export interface IInputs {
    userRole: ComponentFramework.PropertyTypes.StringProperty;
    userName: ComponentFramework.PropertyTypes.StringProperty;
    agentEndpoint: ComponentFramework.PropertyTypes.StringProperty;
    adminFlowUrl: ComponentFramework.PropertyTypes.StringProperty;
    outlookFlowUrl: ComponentFramework.PropertyTypes.StringProperty;
}

export interface IOutputs {
    userRole?: string;
    userName?: string;
    lastMessage?: string;
    activeScreen?: string;
    lastAdminCommand?: string;
}

import { IInputs, IOutputs } from "./generated/ManifestTypes";

// ─── Types ────────────────────────────────────────────────────────────────────

type Screen = "welcome" | "login" | "chat" | "admin";
type UserRole = "student" | "admin" | "guest";
type AdminTab = "commands" | "log";

interface ChatMessage {
    id: string;
    role: "user" | "assistant";
    text: string;
    time: string;
}

interface AdminLogEntry {
    id: string;
    command: string;
    response: string;
    status: "pending" | "success" | "error";
    time: string;
}

interface State {
    screen: Screen;
    userRole: UserRole;
    userName: string;
    selectedLoginRole: "student" | "admin";
    chatMessages: ChatMessage[];
    adminLog: AdminLogEntry[];
    adminTab: AdminTab;
    agentEndpoint: string;
    adminFlowUrl: string;
    outlookFlowUrl: string;
    showPassword: boolean;
    isTyping: boolean;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const uid = (): string => Math.random().toString(36).slice(2, 9);
const now = (): string =>
    new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
const esc = (s: string): string =>
    s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const fmt = (s: string): string =>
    esc(s).replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>").replace(/\n/g, "<br>");

// ─── SVG Assets ───────────────────────────────────────────────────────────────

const HEX_DEFS = `
<defs>
  <linearGradient id="cai-hO" x1="0%" y1="0%" x2="100%" y2="100%">
    <stop offset="0%" stop-color="#e0c3fc"/>
    <stop offset="50%" stop-color="#a855f7"/>
    <stop offset="100%" stop-color="#6d28d9"/>
  </linearGradient>
  <linearGradient id="cai-hI" x1="0%" y1="0%" x2="100%" y2="100%">
    <stop offset="0%" stop-color="#c084fc"/>
    <stop offset="100%" stop-color="#7c3aed"/>
  </linearGradient>
  <linearGradient id="cai-pG" x1="0%" y1="0%" x2="100%" y2="100%">
    <stop offset="0%" stop-color="#9333ea"/>
    <stop offset="100%" stop-color="#4c1d95"/>
  </linearGradient>
  <filter id="cai-gl">
    <feGaussianBlur stdDeviation="3" result="b"/>
    <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
  </filter>
</defs>`;

const hexLogo = (size: number, glow = true): string => `
<svg width="${size}" height="${size}" viewBox="0 0 200 200" fill="none"
     style="${glow ? "filter:drop-shadow(0 0 18px rgba(160,80,255,.7)) drop-shadow(0 0 36px rgba(120,40,220,.4))" : ""}">
  ${HEX_DEFS}
  <polygon points="100,10 175,52.5 175,147.5 100,190 25,147.5 25,52.5"
    fill="none" stroke="url(#cai-hO)" stroke-width="5" opacity=".9"/>
  <line x1="58" y1="18" x2="58" y2="28" stroke="#d8b4fe" stroke-width="2.5" stroke-linecap="round" opacity=".7"/>
  <line x1="142" y1="18" x2="142" y2="28" stroke="#d8b4fe" stroke-width="2.5" stroke-linecap="round" opacity=".7"/>
  <line x1="58" y1="172" x2="58" y2="182" stroke="#d8b4fe" stroke-width="2.5" stroke-linecap="round" opacity=".7"/>
  <line x1="142" y1="172" x2="142" y2="182" stroke="#d8b4fe" stroke-width="2.5" stroke-linecap="round" opacity=".7"/>
  <polygon points="100,28 166,66 166,134 100,172 34,134 34,66"
    fill="url(#cai-hI)" opacity=".95" filter="url(#cai-gl)"/>
  <polygon points="86,68 86,132 148,100" fill="#0a0a0f" opacity=".85"/>
  <path d="M34,100 Q34,60 100,28 Q80,80 86,100 Q80,120 100,172 Q34,140 34,100 Z"
    fill="url(#cai-pG)" opacity=".75"/>
  <polygon points="100,34 158,68 158,132 100,166 42,132 42,68"
    fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="1.5"/>
</svg>`;

const hexLogoBoxed = (size: number): string => `
<svg width="${size}" height="${size}" viewBox="0 0 200 200" fill="none">
  ${HEX_DEFS}
  <rect width="200" height="200" rx="44" fill="#0f0f1e"/>
  <polygon points="100,10 175,52.5 175,147.5 100,190 25,147.5 25,52.5"
    fill="none" stroke="url(#cai-hO)" stroke-width="5" opacity=".9"/>
  <polygon points="100,28 166,66 166,134 100,172 34,134 34,66"
    fill="url(#cai-hI)" opacity=".95"/>
  <polygon points="86,68 86,132 148,100" fill="#0f0f1e" opacity=".9"/>
  <path d="M34,100 Q34,60 100,28 Q80,80 86,100 Q80,120 100,172 Q34,140 34,100 Z"
    fill="url(#cai-pG)" opacity=".75"/>
</svg>`;

const hexMini = (): string => `
<svg width="18" height="18" viewBox="0 0 200 200" fill="none">
  ${HEX_DEFS}
  <polygon points="100,14 166,52 166,140 100,178 34,140 34,52" fill="url(#cai-hI)"/>
  <polygon points="86,68 86,132 148,100" fill="#0a0a0f" opacity=".9"/>
  <path d="M34,96 Q34,56 100,18 Q80,76 86,96 Q80,116 100,178 Q34,138 34,96Z"
    fill="url(#cai-pG)" opacity=".8"/>
</svg>`;

const ICON_SEND = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>`;
const ICON_MIC  = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>`;
const ICON_EYE  = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
const ICON_EYEOFF = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`;
const ICON_REFRESH = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>`;
const ICON_DB   = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>`;
const ICON_DOTS = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>`;
const ICON_MSG  = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>`;

// ─── CSS ─────────────────────────────────────────────────────────────────────

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');

.cai-root *{box-sizing:border-box;margin:0;padding:0}
.cai-root{
  width:100%;height:100%;min-height:580px;
  font-family:'Inter',-apple-system,BlinkMacSystemFont,sans-serif;
  background:#0a0a0f;color:#e8e8ff;
  display:flex;flex-direction:column;overflow:hidden;position:relative;
}

/* ── WELCOME ── */
.cai-hero{
  flex:1;position:relative;overflow:hidden;
  display:flex;flex-direction:column;align-items:center;justify-content:center;
  background:#0a0a0f;min-height:360px;
}
.cai-glow-top{
  position:absolute;top:-40px;left:50%;transform:translateX(-50%);
  width:300px;height:300px;
  background:radial-gradient(circle,rgba(138,43,226,.35) 0%,transparent 70%);
  pointer-events:none;
}
.cai-glow-bot{
  position:absolute;bottom:10px;left:50%;transform:translateX(-50%);
  width:240px;height:120px;
  background:radial-gradient(ellipse,rgba(100,20,200,.2) 0%,transparent 70%);
  pointer-events:none;
}
.cai-grid{
  position:absolute;inset:0;opacity:.05;
  background-image:linear-gradient(rgba(160,100,255,1) 1px,transparent 1px),
                   linear-gradient(90deg,rgba(160,100,255,1) 1px,transparent 1px);
  background-size:28px 28px;
}
.cai-ckt{position:absolute;opacity:.3}
.cai-ckt-l{left:14px;top:50%;transform:translateY(-50%)}
.cai-ckt-r{right:14px;top:50%;transform:translateY(-50%)}
.cai-logo-area{position:relative;z-index:3;display:flex;flex-direction:column;align-items:center;gap:12px}
.cai-brand{
  font-size:26px;font-weight:900;letter-spacing:3px;
  background:linear-gradient(135deg,#c084fc,#a855f7,#7c3aed);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
}
.cai-tagline{font-size:10px;color:rgba(192,132,252,.45);letter-spacing:2.5px;font-weight:500;text-transform:uppercase}
.cai-wave{position:absolute;bottom:0;left:0;width:100%;height:90px;z-index:2}
.cai-welcome-btns{
  background:#0d0d18;padding:24px 20px 28px;
  display:flex;flex-direction:column;gap:10px;
  border-top:1px solid rgba(138,43,226,.2);
}
.cai-terms{font-size:10px;color:rgba(255,255,255,.18);text-align:center;line-height:1.7;margin-top:4px}

/* ── BUTTONS ── */
.cai-btn-p{
  width:100%;padding:13px;border-radius:13px;border:none;
  background:linear-gradient(135deg,#7c3aed,#9333ea,#a855f7);
  color:#fff;font-size:14px;font-weight:700;cursor:pointer;
  font-family:inherit;box-shadow:0 4px 20px rgba(139,92,246,.4);
  transition:all .2s;
}
.cai-btn-p:hover{box-shadow:0 6px 28px rgba(139,92,246,.6);transform:translateY(-1px)}
.cai-btn-s{
  width:100%;padding:13px;border-radius:13px;
  border:1px solid rgba(138,43,226,.3);
  background:rgba(138,43,226,.08);color:rgba(200,160,255,.8);
  font-size:14px;cursor:pointer;font-family:inherit;font-weight:500;transition:all .2s;
}
.cai-btn-s:hover{background:rgba(138,43,226,.15)}

/* ── LOGIN ── */
.cai-login-body{
  background:#0d0d18;padding:22px 20px 26px;
  display:flex;flex-direction:column;gap:12px;overflow-y:auto;flex:1;
}
.cai-login-body::-webkit-scrollbar{width:0}
.cai-l-title{
  font-size:17px;font-weight:800;text-align:center;
  background:linear-gradient(135deg,#c084fc,#a855f7);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
}
.cai-l-sub{font-size:11px;color:#6a6a9a;text-align:center;margin-top:-6px}
.cai-role-lbl{font-size:10px;color:#7a7aaa;font-weight:600;text-transform:uppercase;letter-spacing:.6px}
.cai-role-row{display:flex;gap:8px}
.cai-role-b{
  flex:1;padding:10px 4px;border-radius:11px;
  border:2px solid #2a2a4a;background:#141428;
  color:#7a7aaa;font-size:12px;font-weight:700;
  cursor:pointer;text-align:center;font-family:inherit;
  display:flex;flex-direction:column;align-items:center;gap:4px;transition:all .15s;
}
.cai-role-b.active{border-color:#7c3aed;background:rgba(124,58,237,.18);color:#c084fc}

/* BRIGHT inputs */
.cai-f-lbl{font-size:12px;color:#b0b0d8;font-weight:600;margin-bottom:5px}
.cai-f-inp{
  width:100%;padding:11px 13px;
  background:#1c1c38;border:1.5px solid #3a3a6a;
  border-radius:10px;color:#e8e8ff;font-size:13px;
  outline:none;font-family:inherit;transition:border-color .2s,background .2s;
}
.cai-f-inp:focus{border-color:#a855f7;background:#22224a;box-shadow:0 0 0 2px rgba(168,85,247,.2)}
.cai-f-inp::placeholder{color:#5a5a8a}
.cai-pw-wrap{position:relative}
.cai-pw-wrap .cai-f-inp{padding-right:42px}
.cai-pw-eye{
  position:absolute;right:11px;top:50%;transform:translateY(-50%);
  background:none;border:none;color:#9090c0;cursor:pointer;
  display:flex;align-items:center;padding:2px;
}
.cai-pw-eye:hover{color:#c084fc}
.cai-forgot{
  text-align:right;font-size:12px;color:#c084fc;
  cursor:pointer;font-weight:700;margin-top:-4px;
  background:none;border:none;font-family:inherit;
}
.cai-forgot:hover{color:#e0aaff}
.cai-divider{display:flex;align-items:center;gap:8px;color:#3a3a6a;font-size:11px}
.cai-divider::before,.cai-divider::after{content:'';flex:1;height:1px;background:#2a2a4a}
.cai-btn-outlook{
  width:100%;padding:12px;border:1.5px solid #2a2a4a;border-radius:10px;
  background:#141428;color:#c0c0e0;font-size:13px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;gap:9px;
  font-family:inherit;font-weight:500;transition:all .2s;
}
.cai-btn-outlook:hover{border-color:#7c3aed;background:#1a1a38}

/* ── CHAT ── */
.cai-chat-head{
  display:flex;align-items:center;justify-content:space-between;
  padding:12px 16px;border-bottom:1px solid #1a1a2e;
  background:#0a0a0f;flex-shrink:0;
}
.cai-chat-head-l{display:flex;align-items:center;gap:10px}
.cai-av{
  width:36px;height:36px;border-radius:10px;
  background:linear-gradient(135deg,#7c3aed,#9333ea);
  display:flex;align-items:center;justify-content:center;
  box-shadow:0 0 12px rgba(139,92,246,.5);
}
.cai-av-info strong{display:block;font-size:13px;font-weight:700;color:#fff}
.cai-av-info span{font-size:10px;color:#a855f7}
.cai-h-acts{display:flex;gap:6px}
.cai-icn-b{
  width:28px;height:28px;border-radius:8px;
  background:#0f0f1e;border:1px solid #1e1e3a;
  color:#5a5a8a;display:flex;align-items:center;justify-content:center;
  cursor:pointer;transition:all .15s;
}
.cai-icn-b:hover{background:#1a1a30;color:#c084fc}

.cai-msgs{
  flex:1;overflow-y:auto;padding:14px 14px 6px;
  display:flex;flex-direction:column;gap:10px;
  background:#0a0a0f;
}
.cai-msgs::-webkit-scrollbar{width:0}
.cai-mrow{display:flex;align-items:flex-end;gap:8px;animation:caiMsgIn .25s ease}
.cai-mrow.user{flex-direction:row-reverse}
@keyframes caiMsgIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
.cai-mav{
  width:28px;height:28px;border-radius:8px;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;
}
.cai-mav-bot{background:linear-gradient(135deg,#7c3aed,#9333ea);box-shadow:0 0 8px rgba(139,92,246,.4)}
.cai-mav-usr{background:#1e1e3a;font-size:10px;font-weight:700;color:#a855f7}
.cai-bubble{max-width:74%;padding:9px 13px;border-radius:14px;font-size:12.5px;line-height:1.55}
.cai-bubble-bot{background:#0f0f1e;color:#e2e2f0;border:1px solid #1e1e3a;border-bottom-left-radius:3px}
.cai-bubble-usr{background:linear-gradient(135deg,#7c3aed,#9333ea);color:#fff;border-bottom-right-radius:3px}
.cai-mtime{font-size:9px;color:#2a2a4a;margin-top:3px;display:block}
.cai-mrow.user .cai-mtime{text-align:right}

.cai-typing{
  display:flex;gap:4px;align-items:center;
  padding:10px 14px;background:#0f0f1e;
  border:1px solid #1e1e3a;border-radius:14px;border-bottom-left-radius:3px;
  width:fit-content;
}
.cai-td{width:6px;height:6px;border-radius:50%;background:#4a4a7a;animation:caiTb 1.2s ease-in-out infinite}
.cai-td:nth-child(2){animation-delay:.2s}
.cai-td:nth-child(3){animation-delay:.4s}
@keyframes caiTb{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-5px)}}

.cai-chips{
  display:flex;gap:6px;overflow-x:auto;
  padding:8px 14px 0;background:#0a0a0f;flex-shrink:0;
}
.cai-chips::-webkit-scrollbar{height:0}
.cai-chip{
  flex-shrink:0;padding:6px 12px;background:#0f0f1e;
  border:1px solid #1e1e3a;border-radius:16px;
  color:#9090c0;font-size:11px;cursor:pointer;
  white-space:nowrap;font-family:inherit;transition:all .15s;
}
.cai-chip:hover{border-color:#7c3aed;color:#c084fc}

/* BRIGHT input bar */
.cai-inp-area{padding:8px 12px 18px;background:#0a0a0f;border-top:1px solid #1a1a2e;flex-shrink:0}
.cai-inp-box{
  display:flex;align-items:center;gap:6px;
  background:#1c1c38;border:1.5px solid #3a3a6a;
  border-radius:14px;padding:7px 7px 7px 13px;transition:all .2s;
}
.cai-inp-box:focus-within{border-color:#a855f7;box-shadow:0 0 0 2px rgba(168,85,247,.2)}
.cai-inp-txt{flex:1;background:none;border:none;outline:none;color:#e8e8ff;font-size:13px;font-family:inherit}
.cai-inp-txt::placeholder{color:#5a5a8a;font-size:12px}
.cai-mic-b{
  width:30px;height:30px;border-radius:9px;
  background:#0f0f1e;border:1px solid #2a2a4a;
  color:#9090c0;display:flex;align-items:center;justify-content:center;cursor:pointer;
}
.cai-mic-b:hover{color:#c084fc;border-color:#7c3aed}
.cai-send-b{
  width:30px;height:30px;border-radius:9px;
  background:linear-gradient(135deg,#7c3aed,#9333ea);border:none;
  color:#fff;display:flex;align-items:center;justify-content:center;
  cursor:pointer;box-shadow:0 2px 8px rgba(139,92,246,.4);
}
.cai-send-b:disabled{background:#1a1a2e;box-shadow:none;color:#3a3a5a;cursor:default}

/* ── ADMIN ── */
.cai-admin-head{
  display:flex;align-items:center;justify-content:space-between;
  padding:12px 16px;border-bottom:1px solid #1a1a2e;background:#0a0a0f;flex-shrink:0;
}
.cai-adm-av{
  width:36px;height:36px;border-radius:10px;
  background:linear-gradient(135deg,#5b21b6,#7c3aed);
  display:flex;align-items:center;justify-content:center;
  box-shadow:0 0 12px rgba(91,33,182,.5);font-size:18px;
}
.cai-adm-info strong{display:block;font-size:13px;font-weight:700;color:#fff}
.cai-adm-info span{font-size:10px;color:#7c3aed}

.cai-atabs{display:flex;border-bottom:1px solid #1a1a2e;background:#0a0a0f;flex-shrink:0}
.cai-atab{
  flex:1;padding:9px 4px;border:none;background:none;
  color:#4a4a6a;font-size:10px;font-weight:700;
  cursor:pointer;font-family:inherit;
  border-bottom:2px solid transparent;text-transform:uppercase;letter-spacing:.4px;transition:all .2s;
}
.cai-atab.active{color:#a855f7;border-bottom-color:#a855f7}

.cai-atab-body{flex:1;overflow-y:auto;padding:13px 14px;background:#0a0a0f}
.cai-atab-body::-webkit-scrollbar{width:0}
.cai-slbl{font-size:9px;color:#5a5a8a;font-weight:700;text-transform:uppercase;letter-spacing:.8px;margin-bottom:8px}
.cai-qgrid{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-bottom:14px}
.cai-qcmd{
  padding:11px 8px;background:#0f0f1e;border:1px solid #2a2a4a;
  border-radius:11px;cursor:pointer;text-align:center;transition:all .15s;
}
.cai-qcmd:hover{border-color:#7c3aed;background:rgba(124,58,237,.1)}
.cai-qcmd-icon{font-size:20px;display:block;margin-bottom:5px}
.cai-qcmd-lbl{font-size:10px;color:#7a7aaa;font-weight:600}
.cai-hint{
  background:#0f0f1e;border:1px solid #2a2a4a;border-radius:9px;
  padding:9px 11px;font-size:10px;color:#6a6a9a;margin-bottom:6px;
}
.cai-hint em{color:#a855f7;font-style:normal}

.cai-log-entry{background:#0f0f1e;border:1px solid #1e1e3a;border-radius:11px;padding:10px 12px;margin-bottom:7px}
.cai-log-entry.success{border-left:3px solid #a855f7}
.cai-log-entry.pending{border-left:3px solid #f0a500}
.cai-log-entry.error  {border-left:3px solid #f87171}
.cai-log-cmd{font-size:11px;color:#e2e2f0;font-weight:600;margin-bottom:3px}
.cai-log-resp{font-size:10px;color:#4a4a6a;margin-top:3px}
.cai-log-meta{display:flex;justify-content:space-between;align-items:center;margin-top:6px}
.cai-log-time{font-size:9px;color:#2a2a4a}
.cai-badge{font-size:9px;font-weight:700;padding:2px 8px;border-radius:8px;text-transform:uppercase}
.cai-badge.success{background:rgba(168,85,247,.15);color:#a855f7}
.cai-badge.pending{background:rgba(240,165,0,.15);color:#f0a500}
.cai-badge.error  {background:rgba(248,113,113,.15);color:#f87171}

/* BRIGHT admin input */
.cai-adm-inp{padding:8px 12px 18px;background:#0a0a0f;border-top:1px solid #1a1a2e;flex-shrink:0}
.cai-adm-inp-box{
  display:flex;align-items:center;gap:6px;
  background:#1c1c38;border:1.5px solid #3a3a6a;
  border-radius:14px;padding:7px 7px 7px 13px;transition:all .2s;
}
.cai-adm-inp-box:focus-within{border-color:#a855f7;box-shadow:0 0 0 2px rgba(168,85,247,.2)}
.cai-adm-txt{flex:1;background:none;border:none;outline:none;color:#e8e8ff;font-size:13px;font-family:inherit}
.cai-adm-txt::placeholder{color:#5a5a8a;font-size:12px}
.cai-sub-b{
  width:30px;height:30px;border-radius:9px;
  background:linear-gradient(135deg,#5b21b6,#7c3aed);border:none;
  color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;
}

/* OUTLOOK SVG */
.cai-outlook-logo{display:flex;align-items:center}
`;

// ─── Bot Responses ────────────────────────────────────────────────────────────

const BOT_RESPONSES: Record<string, string> = {
    schedule: "📅 **Today's Schedule (Batch A):**\n• 9:00 AM — Python · Room 201\n• 11:00 AM — Flutter · Bay-3 ⚡\n• 2:00 PM — AWS · Lab-5",
    update:   "⚡ **Emergency Updates:**\n• Flutter → Bay-3 (room change)\n• ML session cancelled\n• Extra Python lab at 4 PM",
    trainer:  "👤 **Trainers:**\n• Python → Mr. Ravi Shankar\n• Flutter → Ms. Priya Mehta\n• AWS → Mr. Kumar Reddy",
    webinar:  "🎥 **Webinars & Virtual Meets:**\n• Cloud Computing — May 15, 3 PM (Teams)\n• React Advanced — May 17, 11 AM (Zoom)\n• AI Workshop — May 20, 2 PM (Meet)\n\n🔗 Links sent via Outlook",
    default:  "I'm here to help! Ask about your schedule, class locations, trainers, or upcoming webinars 🎓",
};

const getStudentReply = (text: string): string => {
    const t = text.toLowerCase();
    if (t.includes("schedule") || t.includes("today") || t.includes("timetable")) return BOT_RESPONSES.schedule;
    if (t.includes("update") || t.includes("emergency") || t.includes("change"))   return BOT_RESPONSES.update;
    if (t.includes("trainer") || t.includes("who") || t.includes("faculty"))       return BOT_RESPONSES.trainer;
    if (t.includes("webinar") || t.includes("meet") || t.includes("virtual") ||
        t.includes("zoom") || t.includes("teams"))                                  return BOT_RESPONSES.webinar;
    return BOT_RESPONSES.default;
};

const ADMIN_COMMANDS = [
    { icon: "🔄", label: "Move Room",    cmd: "Move [class] to [room]",                      color: "#a855f7" },
    { icon: "❌", label: "Cancel Class", cmd: "Cancel today's [class] session",              color: "#f87171" },
    { icon: "📅", label: "No Classes",   cmd: "No classes for [batch] on [date]",            color: "#f0a500" },
    { icon: "🎥", label: "Virtual Meet", cmd: "Schedule virtual meet for [batch] at [time]", color: "#34d399" },
    { icon: "💻", label: "Add Webinar",  cmd: "Add webinar: [topic] on [date] at [time]",    color: "#60a5fa" },
    { icon: "🔗", label: "Share Link",   cmd: "Send webinar link to [batch]",                color: "#c084fc" },
];

// ─── Main PCF Control ─────────────────────────────────────────────────────────

export class CampusAIApp implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private _container!: HTMLDivElement;
    private _root!: HTMLDivElement;
    private _notify!: () => void;
    private _state: State;
    private _recognition?: SpeechRecognition;

    constructor() {
        this._state = {
            screen: "welcome",
            userRole: "guest",
            userName: "",
            selectedLoginRole: "student",
            chatMessages: [],
            adminLog: [],
            adminTab: "commands",
            agentEndpoint: "",
            adminFlowUrl: "",
            outlookFlowUrl: "",
            showPassword: false,
            isTyping: false,
        };
    }

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        _state: ComponentFramework.Dictionary,
        container: HTMLDivElement
    ): void {
        this._container = container;
        this._notify = notifyOutputChanged;
        this._state.agentEndpoint  = context.parameters.agentEndpoint?.raw  || "";
        this._state.adminFlowUrl   = context.parameters.adminFlowUrl?.raw   || "";
        this._state.outlookFlowUrl = context.parameters.outlookFlowUrl?.raw || "";

        // If Power Apps passes user context, skip welcome
        const role = context.parameters.userRole?.raw;
        const name = context.parameters.userName?.raw;
        if (role && name && role !== "guest") {
            this._state.userRole = role as UserRole;
            this._state.userName = name;
            this._state.screen   = role === "admin" ? "admin" : "chat";
        }

        this._injectStyles();
        this._mount();
        this._render();
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        const role = context.parameters.userRole?.raw;
        const name = context.parameters.userName?.raw;
        if (role && name && role !== this._state.userRole) {
            this._state.userRole = role as UserRole;
            this._state.userName = name;
            this._state.screen   = role === "admin" ? "admin" : "chat";
            this._render();
        }
    }

    public getOutputs(): IOutputs {
        return {
            userRole: this._state.userRole,
            userName: this._state.userName,
            activeScreen: this._state.screen,
            lastMessage: this._state.chatMessages.at(-1)?.text ?? "",
            lastAdminCommand: this._state.adminLog[0]?.command ?? "",
        };
    }

    public destroy(): void {
        this._recognition?.stop();
    }

    // ── Private: Mounting ──────────────────────────────────────────────────────

    private _injectStyles(): void {
        if (document.getElementById("cai-styles")) return;
        const s = document.createElement("style");
        s.id = "cai-styles";
        s.textContent = CSS;
        document.head.appendChild(s);
    }

    private _mount(): void {
        this._container.innerHTML = `<div class="cai-root" id="cai-root"></div>`;
        this._root = this._container.querySelector("#cai-root") as HTMLDivElement;
    }

    // ── Private: Navigation ────────────────────────────────────────────────────

    private _go(screen: Screen): void {
        this._state.screen = screen;
        if (screen === "chat" && this._state.chatMessages.length === 0) {
            this._state.chatMessages.push({
                id: uid(), role: "assistant",
                text: `Hey ${this._state.userName || "there"} 👋 I'm your Campus AI assistant. Ask me about your schedule, classes, or webinars!`,
                time: now(),
            });
        }
        this._render();
        this._notify();
    }

    // ── Private: Render ────────────────────────────────────────────────────────

    private _render(): void {
        switch (this._state.screen) {
            case "welcome": this._root.innerHTML = this._tplWelcome(); this._bindWelcome(); break;
            case "login":   this._root.innerHTML = this._tplLogin();   this._bindLogin();   break;
            case "chat":    this._root.innerHTML = this._tplChat();    this._bindChat();    break;
            case "admin":   this._root.innerHTML = this._tplAdmin();   this._bindAdmin();   break;
        }
    }

    // ── Templates ─────────────────────────────────────────────────────────────

    private _tplWelcome(): string {
        return `
        <div class="cai-hero">
            <div class="cai-glow-top"></div>
            <div class="cai-glow-bot"></div>
            <div class="cai-grid"></div>
            <svg class="cai-ckt cai-ckt-l" width="34" height="110" viewBox="0 0 34 110" fill="none">
                <line x1="34" y1="25" x2="18" y2="25" stroke="#7c3aed" stroke-width="1.5"/>
                <line x1="18" y1="25" x2="18" y2="42" stroke="#7c3aed" stroke-width="1.5"/>
                <circle cx="18" cy="42" r="2.5" fill="#a855f7"/>
                <line x1="34" y1="55" x2="8" y2="55" stroke="#5b21b6" stroke-width="1"/>
                <circle cx="8" cy="55" r="2" fill="#7c3aed"/>
                <line x1="34" y1="80" x2="20" y2="80" stroke="#7c3aed" stroke-width="1.5"/>
                <circle cx="20" cy="80" r="2" fill="#a855f7"/>
            </svg>
            <svg class="cai-ckt cai-ckt-r" width="34" height="110" viewBox="0 0 34 110" fill="none">
                <line x1="0" y1="25" x2="16" y2="25" stroke="#7c3aed" stroke-width="1.5"/>
                <line x1="16" y1="25" x2="16" y2="42" stroke="#7c3aed" stroke-width="1.5"/>
                <circle cx="16" cy="42" r="2.5" fill="#a855f7"/>
                <line x1="0" y1="55" x2="26" y2="55" stroke="#5b21b6" stroke-width="1"/>
                <circle cx="26" cy="55" r="2" fill="#7c3aed"/>
                <line x1="0" y1="80" x2="14" y2="80" stroke="#7c3aed" stroke-width="1.5"/>
                <circle cx="14" cy="80" r="2" fill="#a855f7"/>
            </svg>
            <div class="cai-logo-area">
                ${hexLogo(110, true)}
                <div class="cai-brand">CAMPUS AI</div>
                <div class="cai-tagline">Intelligent Campus Assistant</div>
            </div>
            <div class="cai-wave">
                <svg viewBox="0 0 300 90" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" width="100%" height="100%">
                    <path d="M0,50 Q70,15 150,40 Q220,62 300,28 L300,90 L0,90 Z" fill="rgba(138,43,226,.1)"/>
                    <path d="M0,60 Q80,30 160,56 Q240,76 300,46 L300,90 L0,90 Z" fill="rgba(124,58,237,.18)"/>
                    <path d="M0,72 Q90,52 185,68 Q255,78 300,62 L300,90 L0,90 Z" fill="#0d0d18"/>
                </svg>
            </div>
        </div>
        <div class="cai-welcome-btns">
            <button class="cai-btn-p" id="cai-btn-login">Log in or sign up</button>
            <button class="cai-btn-s" id="cai-btn-guest">Continue as guest</button>
            <div class="cai-terms">This app is free · Chats may be reviewed<br>to improve Campus AI services</div>
        </div>`;
    }

    private _tplLogin(): string {
        const sAct = this._state.selectedLoginRole === "student" ? "active" : "";
        const aAct = this._state.selectedLoginRole === "admin"   ? "active" : "";
        const eyeIcon = this._state.showPassword ? ICON_EYEOFF : ICON_EYE;
        const pwType  = this._state.showPassword ? "text" : "password";
        return `
        <div class="cai-login-body">
            <div style="display:flex;justify-content:center">${hexLogoBoxed(56)}</div>
            <div class="cai-l-title">Log in or sign up</div>
            <div class="cai-l-sub">Smarter responses &amp; real-time campus data</div>
            <div class="cai-role-lbl">I am a</div>
            <div class="cai-role-row">
                <button class="cai-role-b ${sAct}" id="cai-rb-student">
                    <span style="font-size:20px">🎓</span>Student
                </button>
                <button class="cai-role-b ${aAct}" id="cai-rb-admin">
                    <span style="font-size:20px">🛡️</span>Admin
                </button>
            </div>
            <div>
                <div class="cai-f-lbl">Email</div>
                <input id="cai-email" class="cai-f-inp" type="email" placeholder="you@college.edu"/>
            </div>
            <div>
                <div class="cai-f-lbl">Password</div>
                <div class="cai-pw-wrap">
                    <input id="cai-pw" class="cai-f-inp" type="${pwType}" placeholder="Enter your password"/>
                    <button class="cai-pw-eye" id="cai-pw-eye">${eyeIcon}</button>
                </div>
            </div>
            <button class="cai-forgot" id="cai-forgot">Forgot password?</button>
            <button class="cai-btn-p" id="cai-btn-continue" style="border-radius:11px;font-size:13px;padding:12px">Continue</button>
            <div class="cai-divider">or</div>
            <button class="cai-btn-outlook" id="cai-btn-outlook">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <rect x="1" y="3" width="13" height="18" rx="2" fill="#0078D4"/>
                    <text x="7.5" y="15" font-size="9" font-weight="800" fill="white" text-anchor="middle" font-family="Arial,sans-serif">O</text>
                    <rect x="12" y="7" width="11" height="11" rx="1.5" fill="#28A8E8"/>
                    <line x1="12" y1="10.5" x2="23" y2="10.5" stroke="white" stroke-width=".8"/>
                    <line x1="12" y1="13.5" x2="23" y2="13.5" stroke="white" stroke-width=".8"/>
                </svg>
                Continue with Outlook
            </button>
        </div>`;
    }

    private _tplChat(): string {
        const msgs = this._state.chatMessages.map(m => {
            if (m.role === "assistant") {
                return `<div class="cai-mrow">
                    <div class="cai-mav cai-mav-bot">${hexMini()}</div>
                    <div><div class="cai-bubble cai-bubble-bot">${fmt(m.text)}</div><span class="cai-mtime">${m.time}</span></div>
                </div>`;
            }
            const initials = (this._state.userName || "ST").slice(0, 2).toUpperCase();
            return `<div class="cai-mrow user">
                <div class="cai-mav cai-mav-usr">${initials}</div>
                <div><div class="cai-bubble cai-bubble-usr">${esc(m.text)}</div><span class="cai-mtime">${m.time}</span></div>
            </div>`;
        }).join("");

        const typing = this._state.isTyping
            ? `<div class="cai-mrow" id="cai-typing">
                <div class="cai-mav cai-mav-bot">${hexMini()}</div>
                <div class="cai-typing"><div class="cai-td"></div><div class="cai-td"></div><div class="cai-td"></div></div>
               </div>`
            : "";

        return `
        <div class="cai-chat-head">
            <div class="cai-chat-head-l">
                <div class="cai-av">${hexMini()}</div>
                <div class="cai-av-info">
                    <strong>Campus AI</strong>
                    <span>● Student Agent · Online</span>
                </div>
            </div>
            <div class="cai-h-acts">
                <button class="cai-icn-b" id="cai-refresh" title="New chat">${ICON_REFRESH}</button>
                <button class="cai-icn-b" title="Dataverse">${ICON_DB}</button>
                <button class="cai-icn-b" id="cai-back-chat" title="Menu">${ICON_DOTS}</button>
            </div>
        </div>
        <div class="cai-msgs" id="cai-msgs">${msgs}${typing}</div>
        <div class="cai-chips">
            <button class="cai-chip" data-q="📅 Today's schedule">📅 Schedule</button>
            <button class="cai-chip" data-q="⚡ Emergency updates">⚡ Updates</button>
            <button class="cai-chip" data-q="🎥 Webinars today">🎥 Webinars</button>
            <button class="cai-chip" data-q="👤 My trainer info">👤 Trainer</button>
        </div>
        <div class="cai-inp-area">
            <div class="cai-inp-box">
                <input id="cai-chat-inp" class="cai-inp-txt" placeholder="Ask Campus AI..."/>
                <button class="cai-mic-b" id="cai-mic">${ICON_MIC}</button>
                <button class="cai-send-b" id="cai-send">${ICON_SEND}</button>
            </div>
        </div>`;
    }

    private _tplAdmin(): string {
        const isCmds = this._state.adminTab === "commands";
        const cmdsAct = isCmds ? "active" : "";
        const logAct  = !isCmds ? "active" : "";

        const qGrid = ADMIN_COMMANDS.map(c => `
            <div class="cai-qcmd" data-cmd="${esc(c.cmd)}">
                <span class="cai-qcmd-icon">${c.icon}</span>
                <span class="cai-qcmd-lbl">${c.label}</span>
            </div>`).join("");

        const logHtml = this._state.adminLog.length === 0
            ? `<div style="padding:30px 0;text-align:center;color:#3a3a5a;font-size:12px">No commands yet</div>`
            : this._state.adminLog.map(e => `
                <div class="cai-log-entry ${e.status}">
                    <div class="cai-log-cmd">${esc(e.command)}</div>
                    <div class="cai-log-resp">${e.response}</div>
                    <div class="cai-log-meta">
                        <span class="cai-log-time">${e.time}</span>
                        <span class="cai-badge ${e.status}">${e.status}</span>
                    </div>
                </div>`).join("");

        return `
        <div class="cai-admin-head">
            <div style="display:flex;align-items:center;gap:10px">
                <div class="cai-adm-av">🛡️</div>
                <div class="cai-adm-info">
                    <strong>${esc(this._state.userName || "Admin")}</strong>
                    <span>● Admin Agent · Active</span>
                </div>
            </div>
            <div class="cai-h-acts">
                <button class="cai-icn-b" id="cai-to-chat" title="Student view">${ICON_MSG}</button>
                <button class="cai-icn-b" id="cai-signout" title="Sign out">${ICON_DOTS}</button>
            </div>
        </div>
        <div class="cai-atabs">
            <button class="cai-atab ${cmdsAct}" id="cai-tab-cmd">⚡ Commands</button>
            <button class="cai-atab ${logAct}"  id="cai-tab-log">📋 Log (${this._state.adminLog.length})</button>
        </div>
        <div class="cai-atab-body">
            ${isCmds ? `
                <div class="cai-slbl">Quick Commands</div>
                <div class="cai-qgrid">${qGrid}</div>
                <div class="cai-slbl">Examples</div>
                <div class="cai-hint"><em>Tip:</em> "Schedule virtual meet for Batch A on May 12 at 10 AM via Teams"</div>
                <div class="cai-hint"><em>Tip:</em> "Add webinar: Cloud Computing by Mr. Kumar on May 15 at 3 PM"</div>
            ` : `
                <div class="cai-slbl">Command History</div>
                ${logHtml}
            `}
        </div>
        <div class="cai-adm-inp">
            <div class="cai-adm-inp-box">
                <input id="cai-adm-inp" class="cai-adm-txt" placeholder="Type command..."/>
                <button class="cai-mic-b" id="cai-adm-mic">${ICON_MIC}</button>
                <button class="cai-sub-b" id="cai-adm-send">${ICON_SEND}</button>
            </div>
        </div>`;
    }

    // ── Bind: Welcome ──────────────────────────────────────────────────────────

    private _bindWelcome(): void {
        this._root.querySelector("#cai-btn-login")?.addEventListener("click", () => this._go("login"));
        this._root.querySelector("#cai-btn-guest")?.addEventListener("click", () => {
            this._state.userRole = "guest";
            this._state.userName = "Guest";
            this._go("chat");
        });
    }

    // ── Bind: Login ────────────────────────────────────────────────────────────

    private _bindLogin(): void {
        this._root.querySelector("#cai-rb-student")?.addEventListener("click", () => {
            this._state.selectedLoginRole = "student";
            this._render();
        });
        this._root.querySelector("#cai-rb-admin")?.addEventListener("click", () => {
            this._state.selectedLoginRole = "admin";
            this._render();
        });
        this._root.querySelector("#cai-pw-eye")?.addEventListener("click", () => {
            this._state.showPassword = !this._state.showPassword;
            this._render();
        });
        this._root.querySelector("#cai-forgot")?.addEventListener("click", () => {
            const email = (this._root.querySelector("#cai-email") as HTMLInputElement)?.value;
            alert(email ? `Password reset link sent to ${email}` : "Enter your email first.");
        });
        const doLogin = () => {
            const email = (this._root.querySelector("#cai-email") as HTMLInputElement)?.value || "";
            this._state.userRole = this._state.selectedLoginRole;
            this._state.userName = email ? email.split("@")[0] : (this._state.selectedLoginRole === "admin" ? "Admin" : "Student");
            this._go(this._state.selectedLoginRole === "admin" ? "admin" : "chat");
        };
        this._root.querySelector("#cai-btn-continue")?.addEventListener("click", doLogin);
        this._root.querySelector("#cai-btn-outlook")?.addEventListener("click", doLogin);
        (this._root.querySelector("#cai-pw") as HTMLInputElement)?.addEventListener("keydown", (e) => {
            if ((e as KeyboardEvent).key === "Enter") doLogin();
        });
    }

    // ── Bind: Chat ─────────────────────────────────────────────────────────────

    private _bindChat(): void {
        const inp    = this._root.querySelector("#cai-chat-inp") as HTMLInputElement;
        const sendBtn= this._root.querySelector("#cai-send") as HTMLButtonElement;

        inp.addEventListener("keydown", (e) => {
            if ((e as KeyboardEvent).key === "Enter" && inp.value.trim()) {
                this._sendStudentMessage(inp.value.trim());
            }
        });
        sendBtn.addEventListener("click", () => {
            if (inp.value.trim()) this._sendStudentMessage(inp.value.trim());
        });
        this._root.querySelectorAll(".cai-chip[data-q]").forEach(chip => {
            chip.addEventListener("click", () => {
                this._sendStudentMessage((chip as HTMLElement).dataset.q || "");
            });
        });
        this._root.querySelector("#cai-refresh")?.addEventListener("click", () => {
            this._state.chatMessages = [];
            this._go("chat");
        });
        this._root.querySelector("#cai-back-chat")?.addEventListener("click", () => {
            if (this._state.userRole === "admin") this._go("admin");
            else this._go("welcome");
        });
        this._root.querySelector("#cai-mic")?.addEventListener("click", () => {
            this._handleMic(inp);
        });
        this._scrollToBottom();
    }

    // ── Bind: Admin ────────────────────────────────────────────────────────────

    private _bindAdmin(): void {
        const inp = this._root.querySelector("#cai-adm-inp") as HTMLInputElement;

        this._root.querySelector("#cai-tab-cmd")?.addEventListener("click", () => {
            this._state.adminTab = "commands"; this._render();
        });
        this._root.querySelector("#cai-tab-log")?.addEventListener("click", () => {
            this._state.adminTab = "log"; this._render();
        });
        this._root.querySelectorAll(".cai-qcmd[data-cmd]").forEach(btn => {
            btn.addEventListener("click", () => {
                inp.value = (btn as HTMLElement).dataset.cmd || "";
                inp.focus();
            });
        });
        const submit = () => {
            if (inp.value.trim()) { this._sendAdminCommand(inp.value.trim()); inp.value = ""; }
        };
        this._root.querySelector("#cai-adm-send")?.addEventListener("click", submit);
        inp.addEventListener("keydown", (e) => { if ((e as KeyboardEvent).key === "Enter") submit(); });
        this._root.querySelector("#cai-to-chat")?.addEventListener("click", () => this._go("chat"));
        this._root.querySelector("#cai-signout")?.addEventListener("click", () => {
            this._state.chatMessages = [];
            this._state.adminLog = [];
            this._state.userName = "";
            this._go("welcome");
        });
        this._root.querySelector("#cai-adm-mic")?.addEventListener("click", () => {
            this._handleMic(inp);
        });
    }

    // ── Logic: Chat ────────────────────────────────────────────────────────────

    private _sendStudentMessage(text: string): void {
        this._state.chatMessages.push({ id: uid(), role: "user", text, time: now() });
        this._state.isTyping = true;
        this._renderMessages();
        this._notify();

        const delay = 800 + Math.random() * 600;
        setTimeout(() => {
            this._state.isTyping = false;
            this._state.chatMessages.push({
                id: uid(), role: "assistant",
                text: getStudentReply(text), time: now(),
            });
            this._renderMessages();
            this._notify();
        }, delay);
    }

    private _renderMessages(): void {
        const area = this._root.querySelector("#cai-msgs");
        if (!area) return;
        const msgs = this._state.chatMessages.map(m => {
            if (m.role === "assistant") {
                return `<div class="cai-mrow"><div class="cai-mav cai-mav-bot">${hexMini()}</div><div><div class="cai-bubble cai-bubble-bot">${fmt(m.text)}</div><span class="cai-mtime">${m.time}</span></div></div>`;
            }
            const initials = (this._state.userName || "ST").slice(0, 2).toUpperCase();
            return `<div class="cai-mrow user"><div class="cai-mav cai-mav-usr">${initials}</div><div><div class="cai-bubble cai-bubble-usr">${esc(m.text)}</div><span class="cai-mtime">${m.time}</span></div></div>`;
        }).join("");
        const typing = this._state.isTyping
            ? `<div class="cai-mrow" id="cai-typing"><div class="cai-mav cai-mav-bot">${hexMini()}</div><div class="cai-typing"><div class="cai-td"></div><div class="cai-td"></div><div class="cai-td"></div></div></div>`
            : "";
        area.innerHTML = msgs + typing;
        area.scrollTop = area.scrollHeight;
    }

    private _scrollToBottom(): void {
        setTimeout(() => {
            const area = this._root.querySelector("#cai-msgs");
            if (area) area.scrollTop = area.scrollHeight;
        }, 50);
    }

    // ── Logic: Admin ───────────────────────────────────────────────────────────

    private _sendAdminCommand(cmd: string): void {
        const entry: AdminLogEntry = {
            id: uid(), command: cmd,
            response: "⏳ Processing with Admin Agent...",
            status: "pending", time: now(),
        };
        this._state.adminLog.unshift(entry);
        this._state.adminTab = "log";
        this._render();

        // Simulate Power Automate flow (replace with real fetch to adminFlowUrl)
        const flowUrl = this._state.adminFlowUrl;
        if (flowUrl) {
            fetch(flowUrl, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ command: cmd, user: this._state.userName }),
            })
            .then(r => r.json())
            .then(data => {
                const idx = this._state.adminLog.findIndex(e => e.id === entry.id);
                if (idx !== -1) {
                    this._state.adminLog[idx].status = "success";
                    this._state.adminLog[idx].response = data.message || "✅ Dataverse updated. Notifications sent via Outlook.";
                }
                this._render();
            })
            .catch(() => {
                const idx = this._state.adminLog.findIndex(e => e.id === entry.id);
                if (idx !== -1) {
                    this._state.adminLog[idx].status = "error";
                    this._state.adminLog[idx].response = "⚠️ Flow error. Check Power Automate.";
                }
                this._render();
            });
        } else {
            // Demo mode
            setTimeout(() => {
                const idx = this._state.adminLog.findIndex(e => e.id === entry.id);
                if (idx !== -1) {
                    this._state.adminLog[idx].status = "success";
                    this._state.adminLog[idx].response = "✅ Dataverse updated. Notifications sent via Outlook.";
                }
                this._render();
            }, 1500);
        }
        this._notify();
    }

    // ── Logic: Mic ─────────────────────────────────────────────────────────────

    private _handleMic(inp: HTMLInputElement): void {
        const SR = (window as Window & { webkitSpeechRecognition?: typeof SpeechRecognition }).webkitSpeechRecognition
               || (window as Window & { SpeechRecognition?: typeof SpeechRecognition }).SpeechRecognition;
        if (!SR) { inp.placeholder = "🎤 Voice not supported"; return; }

        if (this._recognition) {
            this._recognition.stop();
            this._recognition = undefined;
            return;
        }
        this._recognition = new SR();
        this._recognition.continuous = false;
        this._recognition.interimResults = true;
        this._recognition.lang = "en-US";
        this._recognition.onresult = (e: SpeechRecognitionEvent) => {
            inp.value = Array.from(e.results).map(r => r[0].transcript).join("");
        };
        this._recognition.onend = () => { this._recognition = undefined; };
        this._recognition.start();
    }
}

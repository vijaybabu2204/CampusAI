# Campus AI PCF v2 — Purple Hex Theme

A complete Power Apps Component Framework (PCF) control matching the
purple hex-logo interface previewed in Claude.

---

## Files

| File | Purpose |
|------|---------|
| `ControlManifest.Input.xml` | PCF manifest — all bound/output properties |
| `index.ts` | Full app — all 4 screens, styles, logic, bot replies |
| `generated/ManifestTypes.d.ts` | TypeScript types (auto-generated) |
| `package.json` | Build dependencies |
| `tsconfig.json` | TypeScript compiler config |

---

## Screens

| Screen | Route | Description |
|--------|-------|-------------|
| Welcome | Default | Hex logo splash, wave divider, login/guest buttons |
| Login | After "Log in" | Role toggle (Student/Admin), Email, **Password**, **Forgot password**, Outlook SSO |
| Student Chat | After login as Student | Typing indicator, suggestion chips, mic input, bright input bar |
| Admin Panel | After login as Admin | 6 quick commands (Move, Cancel, No Classes, Virtual Meet, Webinar, Share Link), log tab |

---

## PCF Properties

| Property | Type | Usage | Description |
|----------|------|-------|-------------|
| `userRole` | Text | bound | `student` / `admin` / `guest` |
| `userName` | Text | bound | Logged-in user display name |
| `agentEndpoint` | Text | bound | Copilot Studio Direct Line URL |
| `adminFlowUrl` | Text | bound | Power Automate HTTP trigger URL |
| `outlookFlowUrl` | Text | bound | Outlook notification flow URL |
| `lastMessage` | Text | **output** | Last student message (triggers flows) |
| `activeScreen` | Text | **output** | Current screen name |
| `lastAdminCommand` | Text | **output** | Last admin command submitted |

---

## Quick Start (VS Code)

```bash
# 1. Initialize PCF project
pac pcf init --namespace CampusAI --name CampusAIApp --template field

# 2. Replace generated files with this folder's contents

# 3. Install dependencies
npm install

# 4. Run local dev server
npm start
# → Opens https://localhost:8181 with live hot-reload
```

---

## Power Automate Integration

Wire `lastMessage` (output) → Power Apps trigger → HTTP action to Copilot Studio:

```
lastMessage changes
  → Power Apps trigger
  → HTTP POST to agentEndpoint (Copilot Studio DirectLine)
  → Parse bot reply
  → Set variable → back to Canvas App
```

For Admin commands, bind `lastAdminCommand` → HTTP POST to `adminFlowUrl`:

```json
{
  "command": "Move Flutter class to Bay-3",
  "user": "Admin",
  "timestamp": "2026-05-10T09:41:00Z"
}
```

Flow then:
1. Parses NLP via Copilot Studio Admin Agent
2. Writes to Dataverse `emergency_updates` table
3. Sends Outlook notification to affected batch

---

## Dataverse Tables

| Table | Columns |
|-------|---------|
| `weekly_schedule` | batch, technology, trainer, room, day, start_time |
| `emergency_updates` | batch, technology, action, new_room, start_date, end_date, created_by |
| `webinars` | title, presenter, platform, link, date_time, batch |

---

## Deploy to Power Apps

```bash
# Build
npm run build

# Push to your environment
pac pcf push --publisher-prefix campus

# Or package as solution
pac solution init --publisher-name CampusAI --publisher-prefix campus
pac solution add-reference --path .
msbuild /t:restore
msbuild
```
